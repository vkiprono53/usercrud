package com.mufin.usercrud.constants;

public class UserConstant {
    public static String PHONE_EXIST = "This phone number already exist!";
}
